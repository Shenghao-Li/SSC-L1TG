# SSC-L1TG
solve temporal subspace clustering
